using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region LEDHMI_HMI;
#endregion LEDHMI_HMI;

#endregion Definitions;

