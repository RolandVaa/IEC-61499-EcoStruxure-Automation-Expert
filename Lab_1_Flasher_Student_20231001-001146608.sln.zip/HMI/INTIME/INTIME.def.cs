using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region INTIME_HMI;
#endregion INTIME_HMI;

#endregion Definitions;

