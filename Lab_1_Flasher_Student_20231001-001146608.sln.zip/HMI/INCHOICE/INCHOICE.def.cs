using System;
using NxtControl.GuiFramework;
using NxtControl.Services;


#region Definitions;
#region INCHOICE_HMI;
#endregion INCHOICE_HMI;

#endregion Definitions;

